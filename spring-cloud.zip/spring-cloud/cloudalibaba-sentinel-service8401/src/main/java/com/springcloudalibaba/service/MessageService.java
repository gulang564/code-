package com.springcloudalibaba.service;

public interface MessageService {
    public String message();
}
