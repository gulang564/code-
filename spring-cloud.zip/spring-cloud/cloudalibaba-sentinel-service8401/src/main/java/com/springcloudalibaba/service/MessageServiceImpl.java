package com.springcloudalibaba.service;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import org.springframework.stereotype.Service;

@Service
public class MessageServiceImpl implements MessageService {

    @Override
    @SentinelResource( value = "message",blockHandler = "handleException")
    public String message() {
        return "success";
    }

    public String handleException(BlockException ex) {
        System.out.println("自定义异常............");
        return  ex.getClass().getCanonicalName() + "\t服务不可用";
    }
}
