package com.springcloudalibaba.myhandler;

import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.springcloud.entities.CommonResult;

public class CustomerBlockHandler {

    public static CommonResult handleException(BlockException exception) {
        return new CommonResult(2020, "自定义限流处理信息..exception..CustomerBlockHandler"+exception.getMessage());
    }

    public static CommonResult error(BlockException exception) {
        return new CommonResult(2020, "自定义限流处理信息..error..CustomerBlockHandler"+exception.getMessage());
    }
}
