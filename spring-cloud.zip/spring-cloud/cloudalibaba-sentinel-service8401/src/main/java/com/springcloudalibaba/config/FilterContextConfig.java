package com.springcloudalibaba.config;

import org.springframework.context.annotation.Configuration;


/*
* spring-cloud-alibaba v2.1.1.RELEASE后，可以通过配置关闭
spring.cloud.sentinel.web-context-unify=false
*
* spring-cloud-alibaba v2.1.1.RELEASE 当前测试使用就是这个版本，比较尴尬，上面的这些配置是无效的
*  需要在yml文件里面配置这个   spring.cloud.sentinel.filter.enabled=false
*  再加上下面的配置类，才可以是 sentinel 的链路配置生效。

*
* */



@Configuration
public class FilterContextConfig {
   /* @Bean
    public FilterRegistrationBean sentinelFilterRegistration() {
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        registrationBean.setFilter(new CommonFilter());
        registrationBean.addUrlPatterns("/*");
        // 入口资源关闭聚合
        registrationBean.addInitParameter(CommonFilter.WEB_CONTEXT_UNIFY, "false");
        registrationBean.setName("sentinelFilter");
        registrationBean.setOrder(1);

        return registrationBean;
    }*/

}