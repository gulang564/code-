package com.springcloud.lb;


import org.springframework.cloud.client.ServiceInstance;

import java.util.List;

//手写负载均衡算法
public interface LoadBalancer {
    ServiceInstance instances(List<ServiceInstance> serviceInstances);
}
