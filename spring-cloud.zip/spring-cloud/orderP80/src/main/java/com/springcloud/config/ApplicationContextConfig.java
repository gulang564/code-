package com.springcloud.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class ApplicationContextConfig {
    @Bean
    //开启负载均衡，也就是雨露均沾,
    // 负载均衡的意思是，如果有多个可选择的情况，可以按默认选择策略来选择，不是说一定就是每个人平摊
    // 默认情况就是平摊到每个人都上，但是  在com.myRule 包下面配置了一个随机的策略，所以负载均衡使用的是这个随机策略
    //以前认为负载均衡就是，平摊，其实 真正的意思是遇到多个可选，是按什么情况进行选择。而不是懵逼，不知道怎么选
   // @LoadBalanced
    public RestTemplate getRestTemplate(){
        return new RestTemplate();
    }

}
