package com.springcloud.service;

public interface IMessageProvider {
    public String send();
}
