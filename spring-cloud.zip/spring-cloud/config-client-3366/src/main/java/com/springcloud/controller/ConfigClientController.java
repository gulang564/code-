package com.springcloud.controller;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class ConfigClientController {

    @Value("${server.port}")
    private String serverPort;

    //配置文件里面没有，是怎么取得的这个数据呢？  这个数据是远程数据库里面的
    //猜测，在启动的时候，会在配置中心去拿共有的配置文件，再和自己的配置文件整合在一起，最后形成了一个大的文件。加载到内存
    //最后，通过spring的方式可以读取到
    @Value("${config.info}")
    private String configInfo;


    @GetMapping("/configInfo")
    public String getConfigInfo(){
        return "serverPort:"+serverPort+"\t\n\n configInfo: "+configInfo;
    }


}
