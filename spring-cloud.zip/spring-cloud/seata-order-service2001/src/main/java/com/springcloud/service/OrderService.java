package com.springcloud.service;

import com.springcloud.domain.Order;


public interface OrderService{
    void create(Order order);
}

